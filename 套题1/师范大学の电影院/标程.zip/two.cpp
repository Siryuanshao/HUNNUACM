#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int maxn = 510; // 点数
const int maxm = 10010; // 边数
const int inf = 0x3f3f3f3f;

struct Edge
{
    int to, next, cap, flow, cost;
}edge[maxm<<2];

int head[maxn], pre[maxn], dis[maxn];
int n, m, tot, N;
bool vis[maxn];

void init()
{
    memset(head, -1, sizeof(head));
    tot = 0;
}

void addedge(int u, int v, int cap, int cost) // 链式前向星存图
{
    edge[tot].to = v;
    edge[tot].cap = cap;
    edge[tot].cost = cost;
    edge[tot].flow = 0;
    edge[tot].next = head[u];
    head[u] = tot++;
    edge[tot].to = u;
    edge[tot].cap = 0;
    edge[tot].cost = -cost;
    edge[tot].flow = 0;
    edge[tot].next = head[v];
    head[v] = tot++;
}

bool spfa(int s, int t) // spfa寻找最小费用增广路
{
    queue <int> Q;
    for (int i = 0; i <= N; ++i) // 注意N表示所有点数
    {
        dis[i] = inf;
        vis[i] = false;
        pre[i] = -1;
    }
    dis[s] = 0;
    vis[s] = true;
    Q.push(s);
    while (!Q.empty())
    {
        int u = Q.front();
        Q.pop();
        vis[u] = false;
        for (int i = head[u]; i != -1; i = edge[i].next)
        {

            int v = edge[i].to;
            if (edge[i].cap > edge[i].flow && dis[v] > dis[u] + edge[i].cost)
            {
                dis[v] = dis[u] + edge[i].cost;
                pre[v] = i;
                if (!vis[v])
                {
                    vis[v] = true;
                    Q.push(v);
                }
            }
        }
    }
    if (pre[t] == -1)
        return false;
    return true;
}

int minCostMaxflow(int s, int t, int &mincost) // 计算费用
{
    int maxflow = 0;
    mincost = 0;
    while (spfa(s, t))
    {
        int Min = inf;
        for (int i = pre[t]; i != -1; i = pre[edge[i^1].to]) // 每次增加的流量
            Min = min(Min, edge[i].cap - edge[i].flow);
        for (int i = pre[t]; i != -1; i = pre[edge[i^1].to])
        {
            edge[i].flow += Min;
            edge[i^1].flow -= Min;
            mincost += edge[i].cost * Min;
        }
        maxflow += Min;
    }
    return maxflow;
}

struct Node
{
    int s, t, w, id;
}node[maxn<<2];

int main()
{
//    freopen("/Users/taifu/Codes/NOW/data.in", "r", stdin);
//    freopen("/Users/taifu/Codes/NOW/data.out","w",stdout);
    int T, s, t, K, W;
    scanf("%d", &T);
    while (T--)
    {
        scanf("%d%d%d%d", &n, &m, &K, &W);
        init();
        s = 0, t = 2 * m + 1;
        for (int i = 1; i <= m; ++i)
            scanf("%d%d%d%d", &node[i].s, &node[i].t, &node[i].w, &node[i].id);
        for (int i = 1; i <= m; ++i)
            addedge(i, m + i, 1, -node[i].w);
        addedge(s, 2 * m + 2, K, 0); // 超级源和起点，容量为K，费用为0
        addedge(2 * m + 3, t, K, 0); // 终点和超级汇，容量为K，费用为0
        N = 2 * m + 4;
        for (int i = 1; i <= m; ++i)
        {
            addedge(2 * m + 2, i, 1, 0); // 起点和每个视频的入点
            addedge(m + i, 2 * m + 3, 1, 0); // 每个视频的出点和终点
            for (int j = 1; j <= m; ++j)
            {
                if ((i != j) && (node[j].s >= node[i].t)) // 如果播放时间不重合
                {
                    if (node[i].id == node[j].id) // 同类型
                        addedge(m + i, j, 1, W);
                    else
                        addedge(m + i, j, 1, 0); 
                }
            }
        }
        int maxflow, mincost = 0;
        maxflow = minCostMaxflow(s, t, mincost);
        printf("%d\n", -mincost); // 相反数
    }
    return 0;
}